<?php
	// Require DB Connection
	session_start();
	
	$dbh = new PDO("mysql:host=localhost;dbname=gaocdent_calendar", 'gaocdent_admin', 'gaocadmin');
    // Get ALl Event
	$sth = $dbh->prepare("SELECT * FROM events");
	$sth->execute(array($_GET['start'], $_GET['end']));
	$result = $sth->fetchAll(PDO::FETCH_ASSOC);
	echo json_encode($result);