<?php 
class DBController { 
    private $host = "localhost"; 
    private $user = "gaocdent_admin"; 
    private $password = "gaocadmin"; 
    private $database = "gaocdent_calendar"; 
     
    function __construct() { 
        $conn = $this->connectDB(); 
        if(!empty($conn)) { 
            $this->selectDB($conn); 
        } 
    } 
     
    function connectDB() { 
        $conn = ($GLOBALS["___mysqli_ston"] = mysqli_connect($this->host, $this->user, $this->password)); 
        return $conn; 
    } 
     
    function selectDB($conn) { 
        ((bool)mysqli_query($conn, "USE " . $this->database)); 
    } 
     
    function runQuery($query) { 
        $result = mysqli_query($GLOBALS["___mysqli_ston"], $query); 
        while($row=mysqli_fetch_assoc($result)) {  
            $resultset[] = $row; 
        }         
        if(!empty($resultset)) 
            return $resultset; 
    } 
     
    function numRows($query) { 
        $result  = mysqli_query($GLOBALS["___mysqli_ston"], $query); 
        $rowcount = mysqli_num_rows($result); 
        return $rowcount;     
    } 
} 

?> 
