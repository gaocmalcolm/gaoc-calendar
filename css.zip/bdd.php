<?php

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=gaocdent_calendar;charset=utf8', 'gaocdent_admin', 'gaocadmin');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}
