<?php

// Connexion à la base de données
require_once('bdd.php');
	
//echo $_POST['title'];
if (isset($_POST['title']) && isset($_POST['start']) && isset($_POST['end']) && isset($_POST['color'])){
	session_start();
	$branches = $_SESSION['Branch'];
	$title = $_POST['title'];
	$start = $_POST['start'];
	$end = $_POST['end'];
	$color = $_POST['color'];
	$description = $_POST['description'];
	$remarks = $_POST['remarks'];
	

	$sql = "INSERT INTO events(title, start, end, color, description, remarks, branch) values ('$title', '$start', '$end', '$color', '$description', '$remarks', '$branches')";
	//$req = $bdd->prepare($sql);
	//$req->execute();
	
	echo $sql;
	
	$query = $bdd->prepare( $sql );
	if ($query == false) {
	 print_r($bdd->errorInfo());
	 die ('Erreur prepare');
	}
	$sth = $query->execute();
	if ($sth == false) {
	 print_r($query->errorInfo());
	 die ('Erreur execute');
	}

}
header('Location: '.$_SERVER['HTTP_REFERER']);

	
?>
