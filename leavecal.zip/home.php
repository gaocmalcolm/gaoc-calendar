<?php
include "database.php";
require_once('bdd.php');
session_start();
if($_SESSION['username'])
{
	
	
}
else
{
	header("location: index.php");
}
	$user = $_SESSION['username'];
	$branch = $_SESSION['Branch'];
	


//$sql = "SELECT * FROM events ";

//$req = $bdd->prepare($sql);
//$req->execute();

//$events = $req->fetchAll();
	

	
$get_info = "?comment=success";
$get_info1 = "?task=success";


if(isset($_POST['addcomment']))
{
	
	$getDate2 = isset($_GET['date1']) ? $_GET['date1']: date('Y-m-d H:i:s');
	$Msg = $_POST['MsgComment'];
	$datetoday2= $_POST['datetoday2'];
	
	


			$insTblComment = mysqli_query($conn,"INSERT INTO
			comment(
			Message, 
			Date,
			branch
			) 		
			VALUE(
			'$Msg',
			'$datetoday2',
			'$branch'
			)
			");
			
			echo "<script> </script>";
			header("Location: ".$_SERVER['REQUEST_URI'].$get_info);

}

if(isset($_POST['addblockoff']))
{
	

	$getDate3 = isset($_GET['date']) ? $_GET['date']: date('Y-m-d H:i:s');
	$task = $_POST['Task'];
	$datetoday1= $_POST['datetoday1'];

	echo $datetoday1;
			$insTblTask = mysqli_query($conn,"INSERT INTO
			blockoff(
			Message, 
			Date,
			branch
			) 		
			VALUE(
			'$task',
			'$datetoday1',
			'$branch'
			)
			");
			
			echo "<script> </script>";
			header("Location: ".$_SERVER['REQUEST_URI'].$get_info1);
		
}

$getDate = isset($_GET['date']) ? $_GET['date']: date('Y-m-d');
$getDate1 = isset($_GET['date1']) ? $_GET['date1']: date('Y-m-d');
$db_handle = new DBController();
$sql1 = "SELECT * , DATE_FORMAT(Date, '%W, %M %d, %Y' ) as date_f from blockoff where Date(date) = '".$getDate."'";
$faq = $db_handle->runQuery($sql1);

$sql2 = "SELECT * , DATE_FORMAT(Date, '%W, %M %d, %Y' ) as date_f from comment where Date(date) = '".$getDate1."'";
$faq1 = $db_handle->runQuery($sql2);

?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>GAOC Calendar</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/mbExtruder.css" media="all" rel="stylesheet" type="text/css">
		<link href="css/commentbox.css" rel="stylesheet" />
	<!-- FullCalendar -->
	<link href='css/fullcalendar.css' rel='stylesheet' />
<!-- color picker-->
<script src='js/bootstrap-colorpicker.min.js'></script>
        <script src='js/bootstrap-timepicker.min.js'></script>
		<script src='js/bootstrap-colorselector.js'></script>
<!-- -- >

    <!-- Custom CSS -->
    <style>
    body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
	
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script>
	function empty() {
		var x;
		x = document.getElementById("MsgComment").value;
		if (x == "") {
        alert("PLEASE ENTER MESSAGE");
        return false;
				} 
		else
		{
		alert('RECALL SUCCESSFULLY SAVE');
		return true;
			};
}
		function emptytask() {
		var y;
	
		y = document.getElementById("Task").value;
		if (y== "") {
        alert("PLEASE ENTER MESSAGE");
        return false;
				} 
		else
		{
		alert('BLOCK OFF / TASK SUCCESSFULLY SAVE');
		return true;
			};
			
}
		function myFunction() 
		{
		var newcontent = document.getElementByTagName	("p");
		document.getElementById("demo").innerHTML = newcontent.innerHTML;
		}
		</script>
		
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background","#FFF");
		} 
		
		function saveToblockoff(editableObj,column,id) {
			$(editableObj).css("background","#FFF url(img/loading.gif) no-repeat right");
			$.ajax({
				url: "saveblockoff.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					$(editableObj).css("background","#FDFDFD");
				}        
		   });
		}
		</script>
		<script>
		function showEdit(editableObj) {
			$(editableObj).css("background","#FFF");
		} 
		
		function saveTocomment(editableObj,column,id) {
			$(editableObj).css("background","#FFF url(img/loading.gif) no-repeat right");
			$.ajax({
				url: "savecomment.php",
				type: "POST",
				data:'column='+column+'&editval='+editableObj.innerHTML+'&id='+id,
				success: function(data){
					$(editableObj).css("background","#FDFDFD");
				}        
		   });
		}
		</script>
		
		
</head>

<body>

    <!-- Navigation -->
    <nav class="navbar navbar-fixed-top" role="navigation" >
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="home.php"> <img style="max-width:160px; "
             src="img/logo.jpg"> </a>
				
            </div>
			<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
				<a class="dropdown-toggle" data-toggle="dropdown" href="#">
					<span class="glyphicon glyphicon-user"></span> 
					HI, <?php echo strtoupper($user);?> <?php echo strtoupper($branch);?>
					<span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li>
						<a href="logout.php"> 
						<span class="glyphicon glyphicon-log-out"></span>
						Logout</a>
					</li>
				</ul>
			</li>
			</ul>
           
        </div>
        <!-- /.container -->
    </nav>
	<br>
	<div class="container-fluid">
	<div class="col-md-4">
	<div class="panel panel-default"  style="margin-top: 10px; width: 350px; height: 120px">
		<div class="panel-heading">
			<h3 class="panel-title">LEGEND COLOR</h3>
		</div>
		<div class="panel-body">
			<div class="firstrow" style="position:absolute; margin: 0px 0px 10px 0px">
			<div style="width:15px; height:15px; background-color:blue; margin: 3px 0px 2px 5px"><p style="margin-left: 20px">TEST1</p></div>
			<div style="width:15px; height:15px; background-color:red; margin: 3px 0px 2px 5px"><p style="margin-left: 20px">TEST2</p></div>
			<div style="width:15px; height:15px; background-color:green; margin: 3px 0px 2px 5px"><p style="margin-left: 20px">TEST3</p></div>
		</div>	
		<div class="firstrow" style="position:absolute; margin: 0px 0px 10px 110px">
			<div style="width:15px; height:15px; background-color:violet; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST4</p></div>
			<div style="width:15px; height:15px; background-color:black; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST5</p></div>
			<div style="width:15px; height:15px; background-color:purple; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST6</p></div>
		</div>
		<div class="firstrow" style="position:absolute; margin: 0px 0px 10px 230px">
			<div style="width:15px; height:15px; background-color:grey; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST7</p></div>
			<div style="width:15px; height:15px; background-color:yellow; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST8</p></div>
			<div style="width:15px; height:15px; background-color:maroon; margin: 3px 0px 2px 3px"><p style="margin-left: 20px">TEST9</p></div>
		</div>
	</div>
	</div>
	</div>
	<div class="col-md-8">
	<table class="table table-bordered">
		<tr> 
			<td>
				<div class="col-md-5">
					<form class="form-horizontal" method="POST" action="search.php">
						<div class="form-group">
							<label class="control-label" for="Desc">Search</label>
							<div class="input-group">
								<input type="text" class="form-control" id="txtSearchDesc" name="txtSearchDesc" placeholder="Search for...">
								<span class="input-group-btn">
									<button type="submit" class="btn btn-success" id="searchDesc" name="searchDesc" value="Search"> 
										<span class="glyphicon glyphicon-search" aria-hidden="true"></span>
									</button>
								</span>
							</div>
							<div class="instructor_selector">
							<?php
							include "database1.php";
										
							$sql = "SELECT * FROM `tbl_user` GROUP BY `branch`";
								$results = mysqli_query($conn, $sql );
								
							while($rows=mysqli_fetch_array($results))
								{
								?>
								<input type="checkbox" name="branch[]" value="<?php echo $rows['branch'];?>" id="<?php echo $rows['id'];?>" class="ids" <?php echo ($rows['branch'] == $branch ? 'checked' :'' );?>/><?php echo $rows['branch'];?> &nbsp;
								<?php }
								?>
						</div>
						</div>
						
					</form>
				</div>
			</td>	
		</tr>
		</table>
		</div>		
	</div>
    <!-- Page Content -->
    <div class="container-fluid">
	<?php
			$dateblockoff = isset($_GET['date']) ? $_GET['date'] : date('M d, y');
			$daterecall = isset($_GET['date1']) ? $_GET['date1'] : date('M d, y');
			$prev_dateblockoff = date('Y-m-d', strtotime($dateblockoff .' -1 day'));
			$next_dateblockoff = date('Y-m-d', strtotime($dateblockoff .' +1 day'));
			$prev_daterecall = date('Y-m-d', strtotime($daterecall .' -1 day'));
			$next_daterecall = date('Y-m-d', strtotime($daterecall .' +1 day'));
	?>
	<form action="home.php" method="POST">
	<div id="blockoff" class="col-md-2" style="margin-top:50px">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <center><h4 class="">BLOCK OFF / TASK</h4>
                    </center>
					<a href="?date=<?=$prev_dateblockoff;?>" onclick="return true;"><span class="glyphicon glyphicon-menu-left"></span></a>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo date('M d, Y', strtotime($dateblockoff)); ?>&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="?date=<?=$next_dateblockoff; ?>"><span class="glyphicon glyphicon-menu-right"></span></a>
                </div>                
				<div class="actionBox">
					<ul class="commentList">
						<div class="commentText">
						 <table class="tbl-qa">
		  <thead>
		  </thead>
		  <tbody>
		  
		  <?php
			
		  foreach((array)$faq as $k=>$v) {
		  ?>
			  <tr class="table-row" >
		<td contenteditable="true" onBlur="saveToblockoff(this,'Message','<?php echo $faq[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq[$k]["Message"]; ?></td></tr>
		<td> <span class='date sub-text'><?php echo $faq[$k]["date_f"];?></span> </td>
		<?php
		}
		?>
		
		  </tbody>
		</table>
						</div>
					</ul>
				 </div>
               
			   <div class="actionBox">
            <div class="form-group">
                <input class="form-control" id="Task" name="Task" type="text" placeholder="Enter Block off / Task..." />
                <input id="datetoday1" name="datetoday1" type="hidden" class="form-control input-md" value='<?php echo date('Y-m-d H:i:s', strtotime($dateblockoff));?>'/>
            </div>
            <div class="form-group">
                <button class="btn btn-success" name="addblockoff" onClick="return emptytask()">Add</button>
				   </div>
            </div>
        </div>
		</div>
       
            <div class="col-md-8">
                <div id='calendar'> </div>
				</div>
		
		
		<!-- ITO NALANG YUNG IPPALIT SA LEFT SIDE-->
		<!-- /RECALL -->
        <div id="effect" class="col-md-2" style="margin-top: 50px">
            <div class="panel panel-default">
                <div class="panel-heading">
                   <center> <h4 class="">RECALL</h4>
                   </center>
                  			 <a href="?date1=<?=$prev_daterecall;?>" onclick="return true;"><span class="glyphicon glyphicon-menu-left"></span></a>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo date('M d, Y', strtotime($daterecall)); ?>&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="?date1=<?=$next_daterecall;?>"><span class="glyphicon glyphicon-menu-right"></span></a>
                </div>
                			
				<div class="actionBox">
					<ul class="commentList">
						<div class="commentText">
								 <table class="tbl-qa">
		  <thead>
		  </thead>
		  <tbody>
		  
		  <?php
			
		  foreach((array)$faq1 as $k=>$v) {
		  ?>
			  <tr class="table-row" >
		<td contenteditable="true" onBlur="saveTocomment(this,'Message','<?php echo $faq1[$k]["id"]; ?>')" onClick="showEdit(this);"><?php echo $faq1[$k]["Message"]; ?></td></tr>
		<td> <span class='date sub-text'><?php echo $faq1[$k]["date_f"];?></span> </td>
		<?php
		}
		?>
		
		  </tbody>
		</table>
						</div>
					</ul>
				 </div>
				<div class="actionBox">   
					<div class="form-group">
						<input class="form-control" type="text" id="MsgComment" name="MsgComment" placeholder="Enter Recall..." />
						<input id="datetoday2" name="datetoday2" type="hidden" class="form-control input-md" value='<?php echo  date('Y-m-d H:i:s', strtotime($daterecall)); ?>'/>
					</div>
				<div class="form-group">
					<button class="btn btn-success" name="addcomment" onClick="return empty()">Add</button>
				</div>
				
				</div>
				
            </div>
			
        </div>	
    </div>
	</form>
        <!-- /.row -->
		
		<!-- Modal -->
		<div class="modal fade" id="ModalAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="form-horizontal" method="POST" action="addEvent.php">
			
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Add Patient</h4>
			  </div>
			  <div class="modal-body">
				
				  <div class="form-group">
					<label for="title" class="col-sm-2 control-label">Title</label>
					<div class="col-sm-10">
					  <input type="text" name="title" class="form-control" id="title" placeholder="Title">
					</div>
				  </div>
				   
				  <div class="form-group">
					<label for="start" class="col-sm-2 control-label">Start date</label>
					<div class="col-sm-10">
					  <input type="text" name="start" class="form-control" id="start" readonly>
					</div>
				  </div>
				  <div class="form-group">
					<label for="end" class="col-sm-2 control-label">End date</label>
					<div class="col-sm-10">
					  <input type="text" name="end" class="form-control" id="end" readonly>
					</div>
				  </div>
				  <div class="form-group">
					<label for="desc" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
					  <textarea type="text" name="description" class="form-control" id="description" placeholder="description"> </textarea>
					</div>
				  </div>
				  <div class="form-group">
					<label for="remarks" class="col-sm-2 control-label">Remarks</label>
					<div class="col-sm-10">
					  <textarea type="text" name="remarks" class="form-control" id="remarks" placeholder="remarks"> </textarea>
					</div>
				  </div>
				  <div class="form-group">
					<label for="color" class="col-sm-2 control-label">Color</label>
					<div class="col-sm-10">
					  <select name="color" class="form-control" id="color">
						  <option value="">Choose</option>
						  <option style="color:blue;" value="blue" >&#9724; Blue </option>
						  <option style="color:red;" value="red">&#9724; Red</option>
						  <option style="color:green;" value="green">&#9724; Green</option>						  
						  <option style="color:violet;" value="violet">&#9724; Violet</option>
						  <option style="color:black;" value="black">&#9724; Black</option>
						  <option style="color:purple;" value="purple">&#9724; Purple</option>
						  <option style="color:grey;" value="grey">&#9724; Grey</option>
						  <option style="color:yellow;" value="yellow">&#9724; Yellow</option>
						  <option style="color:maroon;" value="maroon">&#9724; Maroon</option>
						</select>
					</div>
				  </div>
				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			  </div>
			</form>
			</div>
		  </div>
		</div>
		
		
		
		<!-- Modal -->
		<div class="modal fade" id="ModalEdit" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
			<div class="modal-content">
			<form class="form-horizontal" method="POST" action="editEventTitle.php">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Edit Event</h4>
			  </div>
			  <div class="modal-body">
				
				  <div class="form-group">
					<label for="title" class="col-sm-2 control-label">Title</label>
					<div class="col-sm-10">
					  <input type="text" name="title" class="form-control" id="title" placeholder="Title">
					</div>
				  </div>
				  <div class="form-group">
					<label for="start" class="col-sm-2 control-label">Start date</label>
					<div class="col-sm-10">
					  <input type="text" name="start" class="form-control" id="start" readonly>
					</div>
				  </div>
				  <div class="form-group">
					<label for="end" class="col-sm-2 control-label">End date</label>
					<div class="col-sm-10">
					  <input type="text" name="end" class="form-control" id="end" readonly>
					</div>
				  </div>
				  <div class="form-group">
					<label for="desc" class="col-sm-2 control-label">Description</label>
					<div class="col-sm-10">
					  <textarea type="text" name="description" class="form-control" id="description" placeholder="description"> </textarea>
					</div>
				  </div>
				  <div class="form-group">
					<label for="remarks" class="col-sm-2 control-label">Remarks</label>
					<div class="col-sm-10">
					  <textarea type="text" name="remarks" class="form-control" id="remarks" placeholder="remarks"> </textarea>
					</div>
				  </div>
				  <div class="form-group">
							
							<label class="col-sm-2 control-label" for="branch"> Branch </label>
							<div class="col-sm-10">
							<?php
								$sql = "SELECT * FROM tbl_user";
								$query = mysqli_query($conn, $sql);
								
								while($array[] = $query -> fetch_object());
								
								array_pop($array);
								
								#print_r($array);
								?>
							
								<select class="form-control" name="selectbranch" id="selectbranch" >
								<option value="" disabled>--Select Branch--</option>
								<?php foreach($array as $option):?>
									<option value="<?php echo $option->branch;?>"> <?php echo $option->branch;?> </option>
								<?php endforeach ?> 
								</select>
								<font style="font-size:8pt;font-family:Arial">
				(*Note: Please disregard this option if you are adding a New Patient Schedule. Thank You.)
				</font> 
							</div>
							</div>
				  <div class="form-group">
                                
                                <div class="col-md-4">
                                    <input id="selectbranch1" name="selectbranch1" class="form-control"  type="text" value="<?php echo $branch ?>" style="display:none" disabled></input>
                                </div>
                    </div>
				  <div class="form-group">
					<label for="color" class="col-sm-2 control-label">Color</label>
					<div class="col-sm-10">
					  <select name="color" class="form-control" id="color">
						  <option value="">Choose</option>
						  <option style="color:blue;" value="blue" >&#9724; Blue </option>
						  <option style="color:red;" value="red">&#9724; Red</option>
						  <option style="color:green;" value="green">&#9724; Green</option>						  
						  <option style="color:violet;" value="violet">&#9724; Violet</option>
						  <option style="color:black;" value="black">&#9724; Black</option>
						  <option style="color:purple;" value="purple">&#9724; Purple</option>
						  <option style="color:grey;" value="grey">&#9724; Grey</option>
						  <option style="color:yellow;" value="yellow">&#9724; Yellow</option>
						  <option style="color:maroon;" value="maroon">&#9724; Maroon</option>
						</select>
					</div>
				  </div>
				    <div class="form-group"> 
						<div class="col-sm-offset-2 col-sm-10">
						  <div class="checkbox">
							<label class="text-danger"><input type="checkbox"  name="delete"> Delete event</label>
						  </div>
						</div>
					</div>
				  
				  <input type="hidden" name="id" class="form-control" id="id">
				
				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="submit" class="btn btn-primary">Save changes</button>
			  </div>
			</form>
			</div>
		  </div>
		</div>
	

    </div>
    <!-- /.container -->

    <!-- jQuery Version 1.11.1 -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<!-- FullCalendar -->
	<script src='js/moment.min.js'></script>
	<script src='js/fullcalendar.min.js'></script>
	
	<script>

	$(document).ready(function() {
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'agendaDay,agendaWeek,month'
			},
			defaultDate: moment(),
			editable: true,
			eventLimit: true, // allow "more" link when too many events
			selectable: true,
			selectHelper: true,
			defaultView: 'agendaDay',
			allDaySlot: false,
			
			dayClick: function(date, allDay, jsEvent, view) {

				//alert('Clicked on: ' + date.format());
				//alert('Coordinates: ' + jsEvent.pageX + ',' + jsEvent.pageY);
				//alert('Current view: ' + view.name);
				if(allDay){
					$('#calendar').fullCalendar('changeView', 'agendaDay');
					$('#calendar').fullCalendar('gotoDate', date);
					$('#ModalAdd').modal('');
				}
					
			},
			select: function(start, end, allDay) {
					
					$('#ModalAdd #start').val(moment(start).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd #end').val(moment(end).format('YYYY-MM-DD HH:mm:ss'));
				$('#ModalAdd').modal('show');
				
			},
			
			eventRender: function(event, element) {
				element.bind('dblclick', function() {
					$('#ModalEdit #id').val(event.id);
					$('#ModalEdit #title').val(event.title);
					$('#ModalEdit #color').val(event.color);
					$('#ModalEdit #start').val(event.start.format('YYYY-MM-DD HH:mm:ss'));
					$('#ModalEdit #end').val(event.end.format('YYYY-MM-DD HH:mm:ss'));
					$('#ModalEdit').modal('show');
				});
				
				
						
			},

			eventDrop: function(event, delta, revertFunc) { // si changement de position

				edit(event);

			},
			eventResize: function(event,revertFunc) { // si changement de longueur

				edit(event);

			},
			events: 'getEvents.php',
			eventRender: function ( event, view ) {
				var returnvalue = false;
				$("input[type=checkbox]:checked").each(function() {
						var result = this.value == event.branch;
						
					returnvalue = returnvalue || result;
					 	
						});
							
							return returnvalue;				
					},
					
		});
	
				
		function edit(event){
			start = event.start.format('YYYY-MM-DD HH:mm:ss');
			if(event.end){
				end = event.end.format('YYYY-MM-DD HH:mm:ss');
			}else{
				end = start;
			}
			
			id =  event.id;
			
			Event = [];
			Event[0] = id;
			Event[1] = start;
			Event[2] = end;
			
			$.ajax({
			 url: 'editEventDate.php',
			 type: "POST",
			 data: {Event:Event},
			 success: function(rep) {
					if(rep == 'OK'){
						alert('Saved');
					}else{
						alert('Saved1.'); 
					}
				}
			});
		}
		$('.instructor_selector').on('change',function(){
    	$('#calendar').fullCalendar('rerenderEvents');
	});
	});
	

</script>

</body>

</html>
