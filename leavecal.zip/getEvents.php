<?php
	// Require DB Connection
	session_start();
	
	$dbh = new PDO("mysql:host=localhost;dbname=calendar", 'root', '');
    // Get ALl Event
	$sth = $dbh->prepare("SELECT * FROM events ORDER BY events.date ASC");
	$sth->execute();
	$result = $sth->fetchAll(PDO::FETCH_ASSOC);
	echo json_encode($result);