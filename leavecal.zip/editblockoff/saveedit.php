<?php 
require_once("dbcontroller.php"); 

$db_handle = new DBController(); 
$result = mysqli_query($GLOBALS["___mysqli_ston"], "UPDATE try set " . $_POST["column"] . " = '".$_POST["editval"]."' WHERE  id=".$_POST["id"]); 
?> 